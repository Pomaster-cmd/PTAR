﻿$ErrorActionPreference='Stop'
$PackRoot=Split-Path -Parent $PSScriptRoot;$S=Join-Path $PackRoot '_PTAR_UNINSTALL\state'
$ExpectedRuntime='cb7202e5097b78c4965a8300a28a6004038d05bbfe1aaa25089e0a2c5f1b8abb';$ExpectedSidecar='d7eef6d9a2c01e40fed34722c86cee36003a636d663a67174515af5086d274f8';$ExpectedIni='bd39b7c703ddf7a8658bed4df620232d00c06972351ca404c2d8386187fd3f50';$ExpectedVersion='dcbccff254f8caec3823a5f57e4d8177428178aa6f0b05cbcfa911288548c8bc'
function Sha([string]$p){if(Test-Path -LiteralPath $p -PathType Leaf){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}return $null}
$l=Join-Path $S 'LATEST_STATE.txt';if(-not(Test-Path -LiteralPath $l -PathType Leaf)){Write-Host '[FAIL] Etat installation absent';exit 2}
$s=(Get-Content -LiteralPath $l -TotalCount 1).Trim();$m=Get-Content -LiteralPath (Join-Path $s 'install_state.json') -Raw|ConvertFrom-Json;$g=[string]$m.game_root;$bad=0
foreach($r in @(@('d3d11.dll',$ExpectedRuntime),@('win81_nis_dx11_x64.dll',$ExpectedRuntime),@('win81_nis.ini',$ExpectedIni),@('win81_nis_version.txt',$ExpectedVersion),@('ptar_borderless.dll',$ExpectedSidecar))){$h=Sha (Join-Path $g $r[0]);if($h -eq $r[1]){Write-Host ('[PASS] '+$r[0])}else{$bad=1;Write-Host ('[FAIL] '+$r[0]+' '+$h)}}
$t=Get-Content -LiteralPath (Join-Path $g 'win81_nis.ini')
foreach($k in @('TargetExe=Warhammer.exe','Enabled=1','UniversalSpatialPresenter=1','PresenterExclusive=0','GraphicsCartographer=0','RootAuthority=0','OutputWidth=1920','OutputHeight=1080','RenderWidth=1280','RenderHeight=720','Overlay=1','FrameGeneration=0')){if($t -contains $k){Write-Host ('[PASS] '+$k)}else{$bad=1;Write-Host ('[FAIL] '+$k)}}
$rb=[IO.File]::ReadAllBytes((Join-Path $g 'd3d11.dll'))
if($rb.Length -ne 336384){$bad=1;Write-Host '[FAIL] runtime size'}else{Write-Host '[PASS] runtime size 336384'}
if($rb[0xCD00] -ne 0xC3){$bad=1;Write-Host '[FAIL] lowres patch byte'}else{Write-Host '[PASS] lowres patch preserved'}
$hookOk=$true;$hook=@(0xE8,0xFD,0x41,0x4F,0x03);for($x=0;$x -lt 5;$x++){if($rb[0xB6FE+$x] -ne $hook[$x]){$hookOk=$false}}
if($hookOk){Write-Host '[PASS] RC38 hook -> RVA 0x03500500'}else{$bad=1;Write-Host '[FAIL] RC38 hook bytes'}
$manifest=Join-Path $PSScriptRoot 'BASE_TRACKED_SHA256.txt';$baseCount=0
foreach($line in Get-Content -LiteralPath $manifest){if($line -match '^([0-9a-fA-F]{64})  (.+)$'){$exp=$Matches[1].ToLowerInvariant();$rel=$Matches[2];$p=Join-Path $PackRoot ($rel -replace '/','\');$h=Sha $p;$baseCount++;if($h -ne $exp){$bad=1;Write-Host ('[FAIL] BASE MODIFIEE '+$rel+' '+$h)}}}
if($baseCount -ne 107){$bad=1;Write-Host ('[FAIL] Base manifest count '+$baseCount)}else{Write-Host '[PASS] BASE GITHUB 107/107 fichiers byte-identiques'}
if($bad){exit 9}else{Write-Host 'VERIFY_RC38_BORDERLESS_AUTHORITY=PASS';exit 0}
