﻿param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$Engine)
$ErrorActionPreference='Stop';$Root=[IO.Path]::GetFullPath($Root);$ov=Join-Path $Root 'RC38_BORDERLESS_AUTHORITY';$own=Join-Path $ov 'OVERLAY_OWNERSHIP.tsv'
function Sha([string]$p){if(Test-Path -LiteralPath $p -PathType Leaf){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}return $null}
$sidecarPath=$null;$sidecarExpected='d7eef6d9a2c01e40fed34722c86cee36003a636d663a67174515af5086d274f8'
$latest=Join-Path $Root '_PTAR_UNINSTALL\state\LATEST_STATE.txt'
if(Test-Path -LiteralPath $latest -PathType Leaf){try{$s=(Get-Content -LiteralPath $latest -TotalCount 1).Trim();$m=Get-Content -LiteralPath (Join-Path $s 'install_state.json') -Raw|ConvertFrom-Json;$sidecarPath=Join-Path ([string]$m.game_root) 'ptar_borderless.dll'}catch{}}
& $Engine -Root $Root;$rc=$LASTEXITCODE;if($rc -ne 0){exit $rc}
if($sidecarPath -and (Test-Path -LiteralPath $sidecarPath -PathType Leaf)){$h=Sha $sidecarPath;if($h -eq $sidecarExpected){Remove-Item -LiteralPath $sidecarPath -Force;Write-Host '[OK] Sidecar RC38 retire du dossier jeu.'}else{Write-Host ('[KEEP] Sidecar modifie/inconnu conserve: '+$h)}}
if(Test-Path -LiteralPath $own -PathType Leaf){foreach($row in Get-Content -LiteralPath $own){if($row -notmatch '^\d+\|'){continue};$a=$row.Split('|');$p=Join-Path $Root ($a[1]-replace '/','\');if(Test-Path -LiteralPath $p -PathType Leaf){if((Sha $p)-eq $a[2]){Remove-Item -LiteralPath $p -Force}else{Write-Host ('[KEEP] Additif RC38 modifie: '+$a[1])}}};Remove-Item -LiteralPath $own -Force -ErrorAction SilentlyContinue}
$dyn=Join-Path $ov 'PTAR_RC38_INSTALL_LAST.log';if(Test-Path -LiteralPath $dyn -PathType Leaf){Remove-Item -LiteralPath $dyn -Force -ErrorAction SilentlyContinue}
foreach($d in @((Join-Path $ov 'payload'),(Join-Path $ov 'evidence'),$ov)){if(Test-Path -LiteralPath $d -PathType Container){try{Remove-Item -LiteralPath $d -Force -ErrorAction Stop}catch{}}}
Write-Host '[PASS] Moteur canonique GitHub execute puis sidecar/additifs RC38 nettoyes par ownership/SHA.';exit 0
