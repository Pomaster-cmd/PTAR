﻿$ErrorActionPreference='Stop'
$PackRoot=Split-Path -Parent $PSScriptRoot
$Payload=Join-Path $PSScriptRoot 'payload'
$StateRoot=Join-Path $PackRoot '_PTAR_UNINSTALL\state'
$Log=Join-Path $PSScriptRoot 'PTAR_RC38_INSTALL_LAST.log'
$ExpectedRuntime='cb7202e5097b78c4965a8300a28a6004038d05bbfe1aaa25089e0a2c5f1b8abb'
$ExpectedSidecar='d7eef6d9a2c01e40fed34722c86cee36003a636d663a67174515af5086d274f8'
$ExpectedIni='bd39b7c703ddf7a8658bed4df620232d00c06972351ca404c2d8386187fd3f50'
$ExpectedVersion='dcbccff254f8caec3823a5f57e4d8177428178aa6f0b05cbcfa911288548c8bc'
$KnownPtar=@(
 '864c0ca8f24f22f6a3cd4c21a0e213f431f5268e69b04e3860c52fe72600fc3c',
 '705ba9a9444726b0578e2f729ffdb5e45a4bf6abe56cc33a2432457ae0e0e5e5',
 '3bc8186ad869dfbe6ad09c0634dd617d486ec5a7bffc9d63b8fa64bb9a1c287d',
 '84d1b210af2fe4c5a534db6b51a5e35d89b81081c0e9de50049a85c86ce3e63c',
 'b874e50599b8f9917f90c6527f030e4cb4eb8932c947aebd15edd0f213a4f282',
 '3d4d777c943ced0f475df1371d3a2f9eeb5eeb80c66e9fb217c4d91057f32453',
 '50cf02fee971e615f0dba26a7614e27b833486a993cf569fe5369a0fa5b41f59',
 '8481ef8d8694e1f1978191e55c30098c1e836cb1c3defade1e3678956402b84d',
 '613714f5ac70bc94867a3044dd067f4de18bb3ef65262c60f0febce2ca9d4c70',
 'a903321a9504bd644f21468ff21877be86e03bf3a7056c92e41e30934b70fe05',
 'cb7202e5097b78c4965a8300a28a6004038d05bbfe1aaa25089e0a2c5f1b8abb'
)
$KnownSidecar=@(
 '4bbf83ac8001c2ef6dabc40f58a3d69fb9e35b72fc922605430463595b2257bd',
 'd7eef6d9a2c01e40fed34722c86cee36003a636d663a67174515af5086d274f8'
)
function Sha([string]$p){if(Test-Path -LiteralPath $p -PathType Leaf){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}return $null}
function L([string]$s){$x='['+(Get-Date -Format 'HH:mm:ss')+'] '+$s;Write-Host $x;Add-Content -LiteralPath $Log -Value $x -Encoding UTF8}
function F([string]$s,[int]$c=90){L ('FAIL: '+$s);exit $c}
function Resolve-GameRoot{if(Test-Path -LiteralPath (Join-Path $PackRoot 'Warhammer.exe') -PathType Leaf){return $PackRoot};$p=Split-Path -Parent $PackRoot;if(Test-Path -LiteralPath (Join-Path $p 'Warhammer.exe') -PathType Leaf){return $p};return $null}
function Get-RegValueState([string]$key,[string]$name){
 $x=[ordered]@{exists=$false;original=$null;installed=$null;applied=$false}
 if(Test-Path -LiteralPath $key){$r=Get-ItemProperty -LiteralPath $key;if($r.PSObject.Properties.Name -contains $name){$x.exists=$true;$x.original=[int]$r.$name}}
 return $x
}
function Restore-PriorRc37RegistryIfOwned{
 $latest=Join-Path $StateRoot 'LATEST_STATE.txt';if(-not(Test-Path -LiteralPath $latest -PathType Leaf)){return}
 try{$s=(Get-Content -LiteralPath $latest -TotalCount 1).Trim();$sp=Join-Path $s 'install_state.json';if(-not(Test-Path -LiteralPath $sp -PathType Leaf)){return};$pm=Get-Content -LiteralPath $sp -Raw|ConvertFrom-Json}catch{return}
 if(([string]$pm.package) -ne 'PTAR_RC37_CORETECH_LOWRES_GUI'){return}
 if(-not(($pm.PSObject.Properties.Name -contains 'registry') -and $pm.registry)){return}
 $key=[string]$pm.registry.key;if(-not(Test-Path -LiteralPath $key)){return}
 foreach($name in @('WindowStyle','AffectGuiResolution')){
  $saved=$pm.registry.values.$name;if(-not $saved){continue};$r=Get-ItemProperty -LiteralPath $key;$curExists=($r.PSObject.Properties.Name -contains $name)
  if(-not $curExists){continue};$cur=[int]$r.$name;if($cur -ne [int]$saved.installed){L ('MIGRATION KEEP '+$name+' changed after RC37: '+$cur);continue}
  if([bool]$saved.exists){Set-ItemProperty -LiteralPath $key -Name $name -Type DWord -Value ([int]$saved.original);L ('MIGRATION RC37 RESTORE '+$name+'='+[int]$saved.original)}else{Remove-ItemProperty -LiteralPath $key -Name $name -ErrorAction Stop;L ('MIGRATION RC37 REMOVE '+$name)}
 }
}
Set-Content -LiteralPath $Log -Value ('START '+(Get-Date).ToString('o')) -Encoding UTF8
$g=Resolve-GameRoot;if(-not $g){F 'Warhammer.exe introuvable : placer le pack dans le dossier du jeu ou dans un sous-dossier direct.' 2}
if(Get-Process Warhammer -ErrorAction SilentlyContinue){F 'Fermer Warhammer avant installation.' 3}
$pr=Join-Path $Payload 'd3d11.dll';$pc=Join-Path $Payload 'win81_nis_dx11_x64.dll';$pi=Join-Path $Payload 'win81_nis.ini';$pv=Join-Path $Payload 'win81_nis_version.txt';$ps=Join-Path $Payload 'ptar_borderless.dll'
if((Sha $pr)-ne $ExpectedRuntime -or (Sha $pc)-ne $ExpectedRuntime -or (Sha $pi)-ne $ExpectedIni -or (Sha $pv)-ne $ExpectedVersion -or (Sha $ps)-ne $ExpectedSidecar){F 'Payload RC38 hash mismatch.' 10}
$a=Join-Path $g 'd3d11.dll';$c=Join-Path $g 'win81_nis_dx11_x64.dll';$i=Join-Path $g 'win81_nis.ini';$v=Join-Path $g 'win81_nis_version.txt';$sd=Join-Path $g 'ptar_borderless.dll'
$PreexistingPtar=$false
foreach($p in @($a,$c)){if(Test-Path -LiteralPath $p -PathType Leaf){$h=Sha $p;if($KnownPtar -notcontains $h){F ('DLL locale inconnue, installation refusee : '+$p+' '+$h) 20};$PreexistingPtar=$true}}
if(Test-Path -LiteralPath $sd -PathType Leaf){$h=Sha $sd;if($KnownSidecar -notcontains $h){F ('Sidecar local inconnu, installation refusee : '+$sd+' '+$h) 22}}
New-Item -ItemType Directory -Path $StateRoot -Force|Out-Null
Restore-PriorRc37RegistryIfOwned
$state=Join-Path $StateRoot ('INSTALL_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'));New-Item -ItemType Directory -Path $state -Force|Out-Null
$m=[ordered]@{schema=4;package='PTAR_RC38_BORDERLESS_AUTHORITY';game_root=$g;pack_root=$PackRoot;installed=@{};original=@{};windowstyle=@{};migration=@{rc37_registry_checked=$true};known_ptar=$KnownPtar}
foreach($r in @(@('d3d11.dll',$a,$ExpectedRuntime),@('win81_nis_dx11_x64.dll',$c,$ExpectedRuntime),@('win81_nis.ini',$i,$ExpectedIni),@('win81_nis_version.txt',$v,$ExpectedVersion),@('ptar_borderless.dll',$sd,$ExpectedSidecar))){
 $n=$r[0];$p=$r[1];$installSha=$r[2];$e=Test-Path -LiteralPath $p -PathType Leaf;$x=[ordered]@{exists=$e;sha=$null;backup=$null;ptar=$false}
 if($e){$x.sha=Sha $p;if(($n -eq 'd3d11.dll') -or ($n -eq 'win81_nis_dx11_x64.dll')){$x.ptar=($KnownPtar -contains $x.sha)}elseif($n -eq 'ptar_borderless.dll'){$x.ptar=($KnownSidecar -contains $x.sha)}else{$x.ptar=$PreexistingPtar};$bk=Join-Path $state ('original_'+$n);Copy-Item -LiteralPath $p -Destination $bk -Force;if((Sha $bk)-ne $x.sha){F ('Backup incoherent '+$n) 21};$x.backup=$bk}
 $m.original[$n]=$x;$m.installed[$n]=$installSha
}
$key='HKCU:\Software\NeoCore Games\Warhammer Martyr\Options';$m.windowstyle.key=$key;$ws=Get-RegValueState $key 'WindowStyle';$m.windowstyle.exists=$ws.exists;$m.windowstyle.original=$ws.original;$m.windowstyle.applied=$false
if(Test-Path -LiteralPath $key){if((-not $ws.exists) -or ([int]$ws.original -ne 1)){Set-ItemProperty -LiteralPath $key -Name WindowStyle -Type DWord -Value 1;$m.windowstyle.applied=$true}}
$m|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $state 'install_state.json') -Encoding UTF8
Set-Content -LiteralPath (Join-Path $StateRoot 'LATEST_STATE.txt') -Value $state -Encoding UTF8
Set-Content -LiteralPath (Join-Path $PackRoot 'win81_nis_install_target.txt') -Value $g -Encoding ASCII
try{
 Copy-Item -LiteralPath $pr -Destination $a -Force;Copy-Item -LiteralPath $pc -Destination $c -Force;Copy-Item -LiteralPath $pi -Destination $i -Force;Copy-Item -LiteralPath $pv -Destination $v -Force;Copy-Item -LiteralPath $ps -Destination $sd -Force
 if((Sha $a)-ne $ExpectedRuntime -or (Sha $c)-ne $ExpectedRuntime -or (Sha $i)-ne $ExpectedIni -or (Sha $v)-ne $ExpectedVersion -or (Sha $sd)-ne $ExpectedSidecar){throw 'Post-install hash mismatch.'}
}catch{
 foreach($n in @('d3d11.dll','win81_nis_dx11_x64.dll','win81_nis.ini','win81_nis_version.txt','ptar_borderless.dll')){$dst=Join-Path $g $n;$o=$m.original[$n];if($o.exists -and $o.backup -and (Test-Path -LiteralPath $o.backup -PathType Leaf)){Copy-Item -LiteralPath $o.backup -Destination $dst -Force}elseif(Test-Path -LiteralPath $dst -PathType Leaf){Remove-Item -LiteralPath $dst -Force}}
 if($m.windowstyle.applied -and (Test-Path -LiteralPath $key)){if($m.windowstyle.exists){Set-ItemProperty -LiteralPath $key -Name WindowStyle -Type DWord -Value ([int]$m.windowstyle.original)}else{Remove-ItemProperty -LiteralPath $key -Name WindowStyle -ErrorAction SilentlyContinue}}
 F ('Installation transaction annulee : '+$_.Exception.Message) 30
}
L 'INSTALL=PASS';L ('GAME_ROOT='+$g);L ('RUNTIME_SHA256='+$ExpectedRuntime);L ('SIDECAR_SHA256='+$ExpectedSidecar);L 'BASE_GITHUB_MAIN=009b8326d0c6f2d7869077ef621c712cca060479';L 'BASE_FILES=107/107_PRESERVED';L 'MODE=RC38_BORDERLESS_AUTHORITY';L 'CONFIG=CANONICAL_GITHUB_MAIN_EXACT';exit 0
